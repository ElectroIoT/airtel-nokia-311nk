#!/bin/sh
# Rollback script for Nokia 311NK LAN Internet repair
echo "Starting rollback..."
if [ -f /configs/backup_lan_repair.tar.gz ]; then
    mkdir -p /tmp/rollback_tmp
    tar -xzf /configs/backup_lan_repair.tar.gz -C /tmp/rollback_tmp
    [ -f /tmp/rollback_tmp/iptables_pre_repair.rules ] && iptables-restore < /tmp/rollback_tmp/iptables_pre_repair.rules
    [ -f /tmp/rollback_tmp/ip6tables_pre_repair.rules ] && ip6tables-restore < /tmp/rollback_tmp/ip6tables_pre_repair.rules
    [ -f /tmp/rollback_tmp/mobileap_cfg.xml ] && cp -f /tmp/rollback_tmp/mobileap_cfg.xml /etc/data/mobileap_cfg.xml
    [ -f /tmp/rollback_tmp/IPACM_cfg.xml ] && cp -f /tmp/rollback_tmp/IPACM_cfg.xml /etc/data/ipa/IPACM_cfg.xml
    [ -f /tmp/rollback_tmp/r7p.sh ] && cp -f /tmp/rollback_tmp/r7p.sh /configs/r7p.sh
    rm -rf /tmp/rollback_tmp
    echo "Rollback restored configuration files and iptables rules."
else
    echo "Backup archive /configs/backup_lan_repair.tar.gz not found!"
    exit 1
fi

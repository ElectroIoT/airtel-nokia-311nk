#!/bin/sh
# Copyright (c) 2018, The Linux Foundation. All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are
# met:
#   * Redistributions of source code must retain the above copyright
#     notice, this list of conditions and the following disclaimer.
#   * Redistributions in binary form must reproduce the above
#     copyright notice, this list of conditions and the following
#     disclaimer in the documentation and/or other materials provided
#     with the distribution.
#   * Neither the name of The Linux Foundation nor the names of its
#     contributors may be used to endorse or promote products derived
#     from this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESS OR IMPLIED
# WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT
# ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS
# BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
# BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
# WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
# OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN
# IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

# Changes from Qualcomm Innovation Center are provided under the following license:
# Copyright (c) 2023 Qualcomm Innovation Center, Inc. All rights reserved.
# SPDX-License-Identifier: BSD-3-Clause-Clear

FindAndMountUBI () {
   partition=$1
   dir=$2
   extra_opts=$3
   ubi_dev_id=$4

   echo "MTD : Detected block device : $dir for $partition"
   mkdir -p $dir

   device="/dev/ubi$ubi_dev_id""_0"

   while [ 1 ]
    do
        if [ -c $device ]
        then
            test -x /sbin/restorecon && /sbin/restorecon $device
            mount -t ubifs $device $dir -o bulk_read$extra_opts
            break
        else
            sleep 0.010
        fi
    done
}

FindAndMountUBIVolume () {
   partition=$1
   dir=$2
   extra_opts=$3
   ubi_dev_id=$4

   mkdir -p $dir
   eval mount -t ubifs ubi$ubi_dev_id:$partition $dir -o bulk_read$extra_opts
   if [ $? -ne 0 ] ; then
       echo "$partition volume mount failed" > /dev/kmsg
   fi
}

#will.shao, modify partition
AR_FormatUBI() {
   partition=$1
   dir=$2
   ubinub=$3
   mtd_block_number=$4
   device=/dev/ubi${ubinub}
   
   ubidetach -p /dev/mtd$mtd_block_number
   sleep 1
   
   ubiformat /dev/mtd$mtd_block_number -y
   sleep 1
   
   ubiattach -m $mtd_block_number -d $ubinub /dev/ubi_ctrl
   sleep 1

   if [ -e $device ];then
      echo "ubiformat $partition success." > /dev/kmsg
   else
      echo "ubiformat $partition failed." > /dev/kmsg
      return 0
   fi

   ubimkvol /dev/ubi${ubinub} -m -N $partition
   sleep 1

   if [ -e ${device}_0  ];then
      echo "ubimkvol success." > /dev/kmsg
      sync
      return 1
   else
      echo "ubimkvol failed." > /dev/kmsg
      return 0
   fi   
}

GetMountResult() {
   partition=$1
   
   mountResult1=`mount | grep $partition`

   if [ "" = "$mountResult1" ]
   then
      echo "Mount $partition fail." > /dev/kmsg
      return 0
   else
      echo "Mount $partition success." > /dev/kmsg
      return 1
   fi
}

FindAndMountUsrdataUBI () {
   partition=$1
   dir=$2
   ubinub=$3

   ubiattach_time=0
   device=/dev/ubi${ubinub}_0

   mtd_block_number=`cat $mtd_file | grep -wi $partition | sed 's/^mtd//' | awk -F ':' '{print $1}'`
   echo "MTD : Detected block device : $dir for $partition" > /dev/kmsg
   mkdir -p $dir

   #attatch ubi
   ubiattach -m $mtd_block_number -d  $ubinub /dev/ubi_ctrl
   while [ 1 ]
   do
      if [ -e $device ]
      then
         break
      else
         sleep 0.01
         ubiattach_time=$((ubiattach_time+1))
         #echo "ubiattach wait times= $ubiattach_time"

         if [ "$ubiattach_time" -gt "200" ]
         then
            echo "ubiattach $partition failed. Start to format the $partition partition ..." > /dev/kmsg
            AR_FormatUBI $partition $dir $ubinub $mtd_block_number
            if [ ! -e $device ] ;then
               echo "ubiattach $partition failed." > /dev/kmsg
               return 0
            fi
            break
         fi
      fi
   done

   #mount volume
   mounttimes=0
   while [ 1 ]
   do
      mount -t ubifs /dev/ubi${ubinub}_0 $dir -o bulk_read
      sleep 0.1
      GetMountResult $partition
      if [ $? -eq 1 ]
      then
         return 1
      fi

      mounttimes=$((mounttimes+1))
      if [ "$mounttimes" -gt "20" ]
      then
         echo "Mount failed, Start to format the $partition partition ..." > /dev/kmsg
         AR_FormatUBI $partition $dir $ubinub $mtd_block_number
         if [ ! -e $device ] ;then
            echo "ubiattach $partition failed." > /dev/kmsg
            return 0
         fi
         sleep 1
         mount -t ubifs /dev/ubi${ubinub}_0 $dir -o bulk_read
         sleep 2
         GetMountResult $partition
         return $?
      fi
   done
}

BindUsrData(){
   partition=$1
   dir=$2

   FindAndMountUsrdataUBI $partition $dir 2

   if [ "$?" == "1" ]
   then
      #mkdir -p $dir/etc
      mkdir -p $dir/log
      mkdir -p $dir/data
      mkdir -p $dir/cache
      mkdir -p $dir/cache/ufs
      mkdir -p $dir/systemrw
      mkdir -p $dir/persist
      mkdir -p /var/volatile/tmp
      
      if [ ! -f $dir/bind_flag ];then
         #cp -a /etc/* $dir/etc/
         cp -a /data/* $dir/data/
         sync;sync
         sleep 1
         touch $dir/bind_flag
         sync
      fi

      #mount --bind $dir/etc/  /etc
      mount --bind $dir/log/  /log
      mount --bind $dir/data/  /data
      mount --bind $dir/cache/  /cache
      mount --bind $dir/systemrw/  /systemrw
      mount --bind $dir/persist/  /persist
   fi
}

ActivePrefix=""
MtdProc="/proc/mtd"
#get active prefix
GetABSystemPrefix() {
   mtdsystem="mtd`cat /sys/class/ubi/ubi0/mtd_num`"
   grep ${mtdsystem} ${MtdProc} | grep "\<system\>"
   [ $? -ne 0 ] && ActivePrefix="b_"
}

ab_system_switch() {
    echo "AB system switch"
}

MountModemSquashfs () {
   dir=$1
   device=/dev/ubiblock1_0

   echo "mount modem squashfs now!!!!!\n" > /dev/kmsg
   mount -t squashfs $device  $dir  -r
   if [  $? -ne $LE_OK ] ; then
      echo  "mount modem failed!" > /dev/kmsg
      ab_system_switch "${ActivePrefix}modem"
   fi
}

mtd_file=/proc/mtd
if [ -x /sbin/restorecon ]; then
    firmware_selinux_opt=",context=system_u:object_r:firmware_t:s0"
else
    firmware_selinux_opt=""
fi

GetABSystemPrefix
MountModemSquashfs /firmware

BindUsrData data /usrdata

# modem_var="firmware$SLOT_SUFFIX"
# is_modem_vol_enabled=`ubinfo -d 0 -N $modem_var`
# if [ ! -z "$is_modem_vol_enabled" ];
# then
#     ubi_dev_id=0
#     eval FindAndMountUBIVolume $modem_var /firmware $firmware_selinux_opt $ubi_dev_id
# else
#     ubi_dev_id=2
#     modem_part_name="modem$SLOT_SUFFIX"
#     if [ "$SLOT_SUFFIX" != "_b" ];
#     then
#         ubi_dev_id=1
#         modem_part_name="modem$SLOT_SUFFIX|modem"
#     fi
#     mtd_block_number=`cat $mtd_file | grep -i -w -E $modem_part_name | sed 's/^mtd//' | awk -F ':' '{print $1}'`
#     ubiattach -m $mtd_block_number -d $ubi_dev_id /dev/ubi_ctrl
#     eval FindAndMountUBI modem$SLOT_SUFFIX /firmware $firmware_selinux_opt $ubi_dev_id
#     mtd_block_number=`cat $mtd_file | grep -i misc | sed 's/^mtd//' | awk -F ':' '{print $1}'`
#     chown 1000:6 /dev/mtd$mtd_block_number
# fi

exit 0

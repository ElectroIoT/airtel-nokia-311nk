#!/bin/sh
# fw3_notify_hook.sh
#
# Copyright (c) 2020 NSB
#
# This script used to save cmd for notify the third party sw when fw3 restart.
#
#

# please replace this example cmd with real notify cmd.
export PATH=/container/docker/bin/docker:$PATH
container_id=`docker container ls | grep tmobile- |awk '{print $1}'`
docker exec -i $container_id  /data/bitdefender/bin/bdagent-manage -reapply_firewall_rules
echo "firewallMgr restart...notify the 3rd party sw done."

#! /bin/sh
fpath=/tmp/upgrade_log
#if [-p $fpath ];then
if [ $fpath ];then
    echo -n ">"
    cat $fpath
else
    echo -n "<"
fi



-- lua mod_evasive
-- (requires lighttpd 1.4.65+)

local addr = lighty.r.req_attr["request.remote-addr"]

-- count number of requests matching remote address (including self)
-- and for which request headers have been received.  This could be
-- extended to count number of requests matching a given path prefix,
-- which is recommended since multiple request objects may be returned
-- on an HTTP/2 connection with multiple active streams.  The code below
-- checks IP-port combination to count HTTP/2 connections only once.
-- (note: port always 0 if listening unix domain sockets; adjust accordingly)
-- (Alternative implementation could omit port check and instead check
--    (i.req_item.stream_id == 0)  -- HTTP/1.x or HTTP/2 control stream
--  if interested in connection count only, instead of matching a path)
local ireq_attr, count, prev, port = nil, 0, 0, 0
for i in lighty.server.irequests() do
  ireq_attr = i.req_attr
  if (ireq_attr["request.remote-addr"] == addr
      and ireq_attr["uri.path"] ~= nil) then
    port = ireq_attr["request.remote-port"]
    if (prev ~= port) then
      prev = port
      -- save desired info; i invalid outside lighty.server.irequests iteration
      count = count + 1
      if (count > 1) then break end
    end
  end
end

-- check if count exceeds policy
-- (adjust count limit to your site needs here and above)
if (count > 100) then
  -- (optional) logging
  print(addr .. ' turned away. Too many connections.')
  -- 403 Forbidden
  return 403
  -- Alternatives:
  -- could set Location response header to alternate site and send 302 redirect
  -- could rewrite the request to a static page for /site-busy.html
  --   (and be sure to also disable caching, e.g. Cache-Control: max-age=0)
end

-- Limitations: (lighttpd mod_evasive had the same limitations.)
-- The above lua scans all active requests for matching remote address, but only
-- sees the current lighttpd process.  This may miss requests when there are
-- multiple lighttpd workers or independent servers.
-- This lua code rejects requests, but does not close connections, so this can
-- be used to limit the number of simultaneous accesses to resource-intensive
-- targets, but this is not very effective to limit number of socket connections
-- from the same IP.

-- General notes: countermeasures should counter some undesirable behavior and
-- countermeasures should be selected based on the undesirable behavior.
-- As mentioned above, lighttpd lua mod_evasive can limit number of parallel
-- requests being serviced for a given set of resources, and the limit can be
-- removed or different for a whitelist of remote addresses.  lighttpd.conf
-- conditionals can set connection.kbytes-per-second to limit bandwidth
-- throughput per connection.  Host firewall or lighttpd mod_access or lua
-- can be used to block remote addresses/networks from accessing server
-- resources.  Additional countermeasures can be implemented in lua, too:
--   https://wiki.lighttpd.net/AbsoLUAtion#Fight-DDoS
--   https://wiki.lighttpd.net/AbsoLUAtion#Mod_Security

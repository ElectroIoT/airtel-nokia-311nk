

((sjcl.beware && sjcl.beware["CBC mode is dangerous because it doesn't protect message integrity."]) ||
    function(){}
)();

(function(global) {
    'use strict';

	function base64url_escape(b64) {
		return b64.replace(/\+/g,'-').replace(/\//g,'_').replace(/=/g,'.');
	}

	function clearElementByTagName(element) {
		var element = document.getElementsByTagName(element), index;
		for (index = element.length - 1; index >= 0; index--) {
			element[index].parentNode.removeChild(element[index]);
		}
	}

    function encrypt(pubkey, plaintext) {
        var aeskey = sjcl.random.randomWords(4, 0);
        var iv = sjcl.random.randomWords(4, 0);
        var pt = sjcl.codec.utf8String.toBits(plaintext);
        var aes = new sjcl.cipher.aes(aeskey);
        var ct = sjcl.mode.cbc.encrypt(aes, pt, iv);
        
        var rsa = new JSEncrypt(); 
        if(rsa.setPublicKey(pubkey) == false)
            return false;

        var base64url = sjcl.codec.base64url;
        var base64 = sjcl.codec.base64;
        var aesinfo = base64.fromBits(aeskey) + ' ' + base64.fromBits(iv);
        var ck = rsa.encrypt(aesinfo);
        if(ck == false)
            return false;

        return {
            ct:base64url.fromBits(ct),
            ck:base64url_escape(ck)
        };
    };

	function sha256(val1, val2) {
		var out = sjcl.hash.sha256.hash(val1 + ":" + val2);
		return sjcl.codec.base64.fromBits(out);
	}
	const module = {
		encrypt,
		encrypt_post_data: function(pubkey, plaintext) {
			var p = encrypt(pubkey, plaintext);
			return  'encrypted=1&ct=' + p.ct + '&ck=' + p.ck;
		},
		sha256,
		base64url_escape,
		sha256url: function(val1, val2) {
			return base64url_escape(sha256(val1, val2));
		},
		aes_decrypt: function(ciphertext) {
			var sid = localStorage.getItem('sid');
			var keyinfo = localStorage.getItem(sid);
			if(keyinfo && ciphertext.length > 0)
			{
				var key_iv = keyinfo.split(' ');
				var key = sjcl.codec.base64.toBits(key_iv[0]);
				var iv = sjcl.codec.base64.toBits(key_iv[1]);
				var ct = sjcl.codec.base64.toBits(ciphertext);
				var aes = new sjcl.cipher.aes(key);
				try{
					var pt = sjcl.mode.cbc.decrypt(aes, ct, iv);
					return sjcl.codec.utf8String.fromBits(pt);
				}catch(err) {
					console.log(err.message);
				}
			}

			return ciphertext;
		},
		clearModalReference: function() {
			document.getElementsByTagName('body')[0].classList.remove('modal-open');
			clearElementByTagName('ngb-modal-backdrop');
			clearElementByTagName('ngb-modal-window');
		}
	};

		// Freeze to prevent modification to properties
		Object.freeze(module);

		// Attach to window as a non-writable, non-configurable property
		try {
		Object.defineProperty(global, 'crypto_page', {
            value: module,
            writable: false,
            configurable: false,
            enumerable: false
		});
		} catch (e) {
		// In very old browsers, fallback to assign (less secure)
		global.crypto_page = module;
		}
	})(window);

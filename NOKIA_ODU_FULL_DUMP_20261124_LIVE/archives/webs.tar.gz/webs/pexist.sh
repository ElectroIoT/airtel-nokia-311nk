#! /bin/sh
echo {
echo -n \"exist\":
echo 1
#grepid="ps |grep '^[[:blank:]]*${1}'|awk '{print \$1}'"
#[ "`eval ${grepid}`" = "${1}" ] && echo 1 || echo 0
echo }
